"use client";

import { Suspense, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2 } from "lucide-react";
import { EditorCore } from "@/core";
import { guardarPendiente, pedirPropuesta } from "@/editor-vertical/puente";

/**
 * /editor-vertical?t=<carpeta _trabajo>&puente=<http://127.0.0.1:7860>
 * Pide la propuesta al editor vertical, crea un proyecto nuevo y abre el editor;
 * ahí se arma la línea de tiempo (ver EditorVerticalImportador).
 */
function Importar() {
	const params = useSearchParams();
	const router = useRouter();
	const [mensaje, setMensaje] = useState("Pidiendo la propuesta al editor vertical…");
	const [error, setError] = useState<string | null>(null);
	const iniciado = useRef(false);

	useEffect(() => {
		if (iniciado.current) return;
		iniciado.current = true;
		const t = params.get("t");
		const puente = (params.get("puente") || "http://127.0.0.1:7860").replace(/\/$/, "");
		if (!t) {
			setError("Falta la carpeta de trabajo (?t=...).");
			return;
		}
		(async () => {
			try {
				// si el editor vertical aún prepara la copia ligera del video, se espera
				for (let intento = 0; ; intento++) {
					const p = await pedirPropuesta(puente, t);
					if (p.listo) {
						const editor = EditorCore.getInstance();
						const id = await editor.project.createNewProject({ name: p.nombre });
						guardarPendiente(id, { puente, propuesta: p });
						router.replace(`/editor/${id}`);
						return;
					}
					if (!p.preparando || intento > 600) throw new Error(p.mensaje || "El video no está listo");
					setMensaje(p.mensaje || "Preparando el video…");
					await new Promise((r) => setTimeout(r, 3000));
				}
			} catch (e) {
				setError(
					e instanceof TypeError
						? `No pude conectar con el editor vertical en ${puente}. ¿Está abierto interfaz.py?`
						: e instanceof Error
							? e.message
							: String(e),
				);
			}
		})();
	}, [params, router]);

	return (
		<div className="bg-background flex h-screen w-screen items-center justify-center">
			<div className="flex max-w-md flex-col items-center gap-4 text-center">
				{error ? (
					<p className="text-destructive text-sm">{error}</p>
				) : (
					<>
						<Loader2 className="text-muted-foreground size-8 animate-spin" />
						<p className="text-muted-foreground text-sm">{mensaje}</p>
					</>
				)}
			</div>
		</div>
	);
}

export default function EditorVerticalPage() {
	return (
		<Suspense fallback={null}>
			<Importar />
		</Suspense>
	);
}
