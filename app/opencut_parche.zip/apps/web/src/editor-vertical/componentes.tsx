"use client";

import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { useEditor } from "@/editor/use-editor";
import {
	enviarCambios,
	importarPropuesta,
	marcarRecien,
	tomarPendiente,
	tomarRecien,
	vinculoDe,
} from "./puente";

/** Si este proyecto se acaba de crear desde el editor vertical, arma su línea de tiempo una sola vez. */
export function EditorVerticalImportador() {
	const editor = useEditor();
	const projectId = useEditor((e) => e.project.getActiveOrNull()?.metadata.id);
	const hecho = useRef<string | null>(null);

	useEffect(() => {
		if (!projectId || hecho.current === projectId) return;
		hecho.current = projectId;
		if (tomarRecien(projectId)) {
			toast.success("Propuesta lista", {
				description:
					"Mueve o estira los bloques. Para cambiar una toma, edita su texto (DIVIDIDA, PANTALLA COMPLETA, SOLO NACHO). Para quitar una imagen, bórrala u ocúltala. Al terminar: «Enviar a editor vertical».",
				duration: 15000,
			});
			return;
		}
		const pendiente = tomarPendiente(projectId);
		if (!pendiente) return;
		const id = toast.loading("Armando la propuesta del editor vertical…");
		importarPropuesta({
			editor,
			puente: pendiente.puente,
			propuesta: pendiente.propuesta,
			onPaso: (txt) => toast.loading(txt, { id }),
		})
			.then(() => {
				// se recarga para que la línea de tiempo abra mostrando todo el video
				marcarRecien(projectId);
				window.location.reload();
			})
			.catch((e) =>
				toast.error("No pude armar la propuesta", {
					id,
					description: e instanceof Error ? e.message : String(e),
				}),
			);
	}, [editor, projectId]);

	return null;
}

/** Botón de la barra superior: solo aparece en proyectos que vienen del editor vertical. */
export function EnviarEditorVerticalButton() {
	const editor = useEditor();
	const projectId = useEditor((e) => e.project.getActiveOrNull()?.metadata.id);
	const [vinculado, setVinculado] = useState(false);
	const [enviando, setEnviando] = useState(false);

	useEffect(() => {
		// el vínculo se guarda al terminar de importar: se revisa de nuevo un momento después
		const revisar = () => setVinculado(Boolean(projectId && vinculoDe(projectId)));
		revisar();
		const timer = setInterval(revisar, 1500);
		return () => clearInterval(timer);
	}, [projectId]);

	if (!vinculado) return null;

	const enviar = async () => {
		setEnviando(true);
		try {
			const msg = await enviarCambios({ editor });
			toast.success(msg, {
				description: "Regresa a la pestaña Edición del editor vertical: se recarga sola.",
			});
		} catch (e) {
			toast.error("No se enviaron los cambios", {
				description: e instanceof Error ? e.message : String(e),
			});
		} finally {
			setEnviando(false);
		}
	};

	return (
		<Button size="sm" onClick={enviar} disabled={enviando} className="h-8">
			{enviando ? "Enviando…" : "Enviar a editor vertical"}
		</Button>
	);
}
