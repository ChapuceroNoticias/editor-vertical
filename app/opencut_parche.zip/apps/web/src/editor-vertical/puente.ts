/**
 * Puente con el "editor vertical" (programa en Python, interfaz.py).
 *
 * Ida: /editor-vertical?t=<carpeta _trabajo>&puente=<http://127.0.0.1:7860>
 *   crea un proyecto 1080x1920 con el video ya sin pausas, las imágenes de los momentos
 *   y los tramos de pantalla como textos. Cada bloque lleva su clave en el nombre: "[m3] ...".
 * Vuelta: el botón «Enviar a editor vertical» manda los tiempos de esos bloques a /oc/enviar.
 */
import type { EditorCore } from "@/core";
import {
	AddMediaAssetCommand,
	AddTrackCommand,
	BatchCommand,
	InsertElementCommand,
	ToggleTrackVisibilityCommand,
	UpdateElementsCommand,
	type Command,
} from "@/commands";
import { processMediaAssets } from "@/media/processing";
import { storageService } from "@/services/storage/service";
import { buildElementFromMedia, buildTextElement } from "@/timeline/element-utils";
import { mediaTimeFromSeconds, mediaTimeToSeconds } from "@/wasm";
import type { TimelineElement, TimelineTrack } from "@/timeline";

const CLAVE_PENDIENTE = "editor-vertical:pendiente";
const CLAVE_PROYECTOS = "editor-vertical:proyectos";
const CLAVE_RECIEN = "editor-vertical:recien";

/** Marca que el proyecto se acaba de armar (para avisar después de recargar la página). */
export function marcarRecien(projectId: string) {
	escribirJSON(sessionStorage, CLAVE_RECIEN, projectId);
}

export function tomarRecien(projectId: string): boolean {
	const id = leerJSON<string | null>(sessionStorage, CLAVE_RECIEN, null);
	if (id !== projectId) return false;
	try {
		sessionStorage.removeItem(CLAVE_RECIEN);
	} catch {
		/* nada */
	}
	return true;
}

export interface BloqueImagen {
	k: string;
	inicio: number;
	fin: number;
	oculto: boolean;
	nombre: string;
	url: string;
	/** dónde va en el cuadro 1080x1920: [x, y, ancho, alto] (la imagen llega ya recortada a ese tamaño) */
	area?: [number, number, number, number];
}

export interface BloquePantalla {
	k: string;
	inicio: number;
	fin: number;
	op: string;
	texto: string;
	tipo: string;
}

export interface Propuesta {
	ok: boolean;
	listo?: boolean;
	preparando?: boolean;
	mensaje?: string;
	t: string;
	firma: string;
	estilo: string;
	nombre: string;
	duracion: number;
	video: { url: string; nombre: string; vertical?: boolean };
	imagenes: BloqueImagen[];
	pantalla: BloquePantalla[];
	titulo: { k: string; inicio: number; fin: number; texto: string } | null;
}

export interface Vinculo {
	puente: string;
	t: string;
	firma: string;
}

// Colores de cada forma de pantalla (los mismos de la línea de tiempo del editor vertical)
const COLORES: Record<string, string> = {
	completa: "#e11d48",
	dividida: "#0ea5e9",
	nacho: "#52525b",
	cerca: "#f59e0b",
	lejos: "#b45309",
};

// ---------- guardado local ----------
function leerJSON<T>(storage: Storage, clave: string, defecto: T): T {
	try {
		const txt = storage.getItem(clave);
		return txt ? (JSON.parse(txt) as T) : defecto;
	} catch {
		return defecto;
	}
}

function escribirJSON(storage: Storage, clave: string, valor: unknown) {
	try {
		storage.setItem(clave, JSON.stringify(valor));
	} catch {
		/* almacenamiento bloqueado: no pasa nada grave */
	}
}

export function guardarPendiente(
	projectId: string,
	datos: { puente: string; propuesta: Propuesta },
) {
	escribirJSON(sessionStorage, CLAVE_PENDIENTE, { projectId, ...datos });
}

export function tomarPendiente(
	projectId: string,
): { puente: string; propuesta: Propuesta } | null {
	const p = leerJSON<{
		projectId?: string;
		puente: string;
		propuesta: Propuesta;
	} | null>(sessionStorage, CLAVE_PENDIENTE, null);
	if (!p || p.projectId !== projectId) return null;
	try {
		sessionStorage.removeItem(CLAVE_PENDIENTE);
	} catch {
		/* nada */
	}
	return { puente: p.puente, propuesta: p.propuesta };
}

export function vinculoDe(projectId: string): Vinculo | null {
	const todos = leerJSON<Record<string, Vinculo>>(
		localStorage,
		CLAVE_PROYECTOS,
		{},
	);
	return todos[projectId] ?? null;
}

function guardarVinculo(projectId: string, v: Vinculo) {
	const todos = leerJSON<Record<string, Vinculo>>(
		localStorage,
		CLAVE_PROYECTOS,
		{},
	);
	todos[projectId] = v;
	escribirJSON(localStorage, CLAVE_PROYECTOS, todos);
}

// ---------- ida ----------
export async function pedirPropuesta(
	puente: string,
	t: string,
): Promise<Propuesta> {
	const r = await fetch(
		`${puente}/oc/propuesta?t=${encodeURIComponent(t)}`,
		{ cache: "no-store" },
	);
	const d = (await r.json()) as Propuesta;
	if (!d.ok) throw new Error(d.mensaje || "El editor vertical no dio la propuesta");
	return d;
}

async function descargar(url: string, nombre: string): Promise<File> {
	const r = await fetch(url, { cache: "no-store" });
	if (!r.ok) throw new Error(`No pude descargar ${nombre} (${r.status})`);
	const blob = await r.blob();
	return new File([blob], nombre, { type: blob.type || undefined });
}

const nombreBloque = (k: string, texto: string) => `[${k}] ${texto}`;

function etiquetaPantalla({
	bloque,
	canvas,
}: {
	bloque: BloquePantalla;
	canvas: { width: number; height: number };
}) {
	return buildTextElement({
		startTime: mediaTimeFromSeconds({ seconds: bloque.inicio }),
		raw: {
			name: nombreBloque(bloque.k, bloque.tipo),
			duration: mediaTimeFromSeconds({
				seconds: Math.max(0.1, bloque.fin - bloque.inicio),
			}),
			params: {
				content: bloque.texto,
				fontSize: 5,
				fontWeight: "bold",
				color: "#ffffff",
				"background.enabled": true,
				"background.color": COLORES[bloque.op] ?? "#52525b",
				"transform.positionY": -canvas.height * 0.44,
			},
		},
	});
}

export async function importarPropuesta({
	editor,
	puente,
	propuesta,
	onPaso,
}: {
	editor: EditorCore;
	puente: string;
	propuesta: Propuesta;
	onPaso?: (txt: string) => void;
}) {
	const project = editor.project.getActive();
	const projectId = project.metadata.id;
	const canvas = { width: 1080, height: 1920 };

	// 1) archivos: video sin pausas + una imagen por momento
	onPaso?.("Descargando el video…");
	const archivos: File[] = [
		await descargar(`${puente}${propuesta.video.url}`, `${propuesta.video.nombre}.mp4`),
	];
	for (const [n, im] of propuesta.imagenes.entries()) {
		onPaso?.(`Descargando imágenes (${n + 1}/${propuesta.imagenes.length})…`);
		archivos.push(await descargar(`${puente}${im.url}`, `${im.k}.jpg`));
	}
	onPaso?.("Preparando los archivos…");
	const procesados = await processMediaAssets({ files: archivos });
	const porNombre = new Map(procesados.map((a) => [a.name, a]));

	const comandos: Command[] = [];
	const medios: Array<{ id: string; asset: (typeof procesados)[number] }> = [];
	const agregarMedio = (nombre: string) => {
		const asset = porNombre.get(nombre);
		if (!asset) return null;
		const cmd = new AddMediaAssetCommand({ projectId, asset });
		comandos.push(cmd);
		const m = { id: cmd.getAssetId(), asset };
		medios.push(m);
		return m;
	};

	// 2) pista principal: el video
	const tracks = editor.scenes.getActiveScene().tracks;
	const video = agregarMedio(`${propuesta.video.nombre}.mp4`);
	if (!video) throw new Error("OpenCut no pudo leer el video");
	comandos.push(
		new InsertElementCommand({
			placement: { mode: "explicit", trackId: tracks.main.id },
			element: buildElementFromMedia({
				mediaId: video.id,
				mediaType: "video",
				name: propuesta.video.nombre,
				duration: mediaTimeFromSeconds({
					seconds: video.asset.duration ?? propuesta.duracion,
				}),
				startTime: mediaTimeFromSeconds({ seconds: 0 }),
			}),
		}),
	);

	// 3) pista de imágenes
	if (propuesta.imagenes.length) {
		const pista = new AddTrackCommand({ type: "video", index: 0 });
		comandos.push(pista);
		for (const im of propuesta.imagenes) {
			const m = agregarMedio(`${im.k}.jpg`);
			if (!m) continue;
			const el = buildElementFromMedia({
				mediaId: m.id,
				mediaType: "image",
				name: nombreBloque(im.k, im.nombre),
				duration: mediaTimeFromSeconds({
					seconds: Math.max(0.1, im.fin - im.inicio),
				}),
				startTime: mediaTimeFromSeconds({ seconds: im.inicio }),
			});
			if (im.oculto && "hidden" in el) el.hidden = true;
			if (im.area) {
				// OpenCut ajusta la imagen dentro del cuadro (contener); se escala y mueve para que ocupe su área
				const [x, y, w, h] = im.area;
				const escala = 1 / Math.min(canvas.width / w, canvas.height / h);
				el.params = {
					...el.params,
					"transform.scaleX": escala,
					"transform.scaleY": escala,
					"transform.positionX": x + w / 2 - canvas.width / 2,
					"transform.positionY": y + h / 2 - canvas.height / 2,
				};
			}
			comandos.push(
				new InsertElementCommand({
					placement: { mode: "explicit", trackId: pista.getTrackId() },
					element: el,
				}),
			);
		}
	}

	// 4) pista de tramos de pantalla (textos de colores). Con el video ya armado en vertical la pista va oculta
	//    (el cuadro ya muestra cómo se ve); sus bloques siguen en la línea de tiempo para moverlos o editarlos.
	if (propuesta.pantalla.length) {
		const pista = new AddTrackCommand({ type: "text", index: 0 });
		comandos.push(pista);
		if (propuesta.video.vertical) {
			comandos.push(new ToggleTrackVisibilityCommand(pista.getTrackId()));
		}
		for (const b of propuesta.pantalla) {
			comandos.push(
				new InsertElementCommand({
					placement: { mode: "explicit", trackId: pista.getTrackId() },
					element: etiquetaPantalla({ bloque: b, canvas }),
				}),
			);
		}
	}

	// 5) título (estilo motivacional): su orilla derecha = cuándo se quita
	if (propuesta.titulo) {
		const pista = new AddTrackCommand({ type: "text", index: 0 });
		comandos.push(pista);
		comandos.push(
			new InsertElementCommand({
				placement: { mode: "explicit", trackId: pista.getTrackId() },
				element: buildTextElement({
					startTime: mediaTimeFromSeconds({ seconds: 0 }),
					raw: {
						name: nombreBloque("ti", "TÍTULO"),
						duration: mediaTimeFromSeconds({
							seconds: Math.max(0.3, propuesta.titulo.fin),
						}),
						params: {
							content: propuesta.titulo.texto,
							fontSize: 6,
							fontWeight: "bold",
							color: "#ffffff",
							"background.enabled": true,
							"background.color": "#000000",
							"transform.positionY": -canvas.height * 0.3,
						},
					},
				}),
			}),
		);
	}

	onPaso?.("Armando la línea de tiempo…");
	editor.command.execute({ command: new BatchCommand(comandos) });
	// OpenCut toma el tamaño del primer video que se inserta (16:9): se regresa a vertical después
	await editor.project.updateSettings({
		settings: {
			canvasSize: canvas,
			canvasSizeMode: "custom",
			lastCustomCanvasSize: canvas,
			originalCanvasSize: canvas,
		},
		pushHistory: false,
	});
	// que la línea de tiempo muestre todo el video al abrir
	const ancho = Math.max(600, window.innerWidth - 260) * 0.9;
	editor.project.setTimelineViewState({
		viewState: {
			zoomLevel: Math.max(0.1, ancho / (Math.max(1, propuesta.duracion) * 50)),
			scrollLeft: 0,
			playheadTime: mediaTimeFromSeconds({ seconds: 0 }),
		},
	});
	// OpenCut guarda los archivos en segundo plano: aquí se espera a que queden guardados de verdad
	onPaso?.("Guardando en el navegador…");
	await Promise.all(
		medios.map(({ id, asset }) =>
			storageService.saveMediaAsset({ projectId, mediaAsset: { ...asset, id } }),
		),
	);
	await editor.save.flush();
	for (let i = 0; i < 50 && editor.save.getIsDirty(); i++) {
		await new Promise((r) => setTimeout(r, 100));
	}
	guardarVinculo(projectId, {
		puente,
		t: propuesta.t,
		firma: propuesta.firma,
	});
}

// ---------- vuelta ----------
function clave(nombre: string): string | null {
	const m = /^\[([a-z]+[0-9._]*)\]/i.exec(nombre.trim());
	return m ? m[1] : null;
}

function tiempos(el: TimelineElement) {
	const inicio = mediaTimeToSeconds({ time: el.startTime });
	return { inicio, fin: inicio + mediaTimeToSeconds({ time: el.duration }) };
}

async function aBase64(file: Blob): Promise<string> {
	const buf = new Uint8Array(await file.arrayBuffer());
	let bin = "";
	for (let i = 0; i < buf.length; i += 0x8000) {
		bin += String.fromCharCode(...buf.subarray(i, i + 0x8000));
	}
	return btoa(bin);
}

/**
 * Lo que se manda de regreso:
 *  - elementos: los bloques que vinieron del editor vertical (con su clave [m3], [p0]…),
 *  - nuevas: imágenes que agregaste en OpenCut (se vuelven momentos nuevos con esa foto),
 *  - tramos_nuevos: textos que agregaste con DIVIDIDA / PANTALLA COMPLETA (tramo nuevo de pantalla).
 */
export async function bloquesDelProyecto(editor: EditorCore) {
	const { tracks } = editor.scenes.getActiveScene();
	const todas: TimelineTrack[] = [tracks.main, ...tracks.overlay, ...tracks.audio];
	const assets = new Map(editor.media.getAssets().map((a) => [a.id, a]));
	const elementos: Array<{ k: string; inicio: number; fin: number; texto?: string; oculto: boolean }> = [];
	const nuevas: Array<{ inicio: number; fin: number; nombre: string; datos: string; oculto: boolean }> = [];
	const tramosNuevos: Array<{ inicio: number; fin: number; texto: string }> = [];
	for (const pista of todas) {
		const pistaOculta = "hidden" in pista && pista.hidden;
		for (const el of pista.elements as TimelineElement[]) {
			const { inicio, fin } = tiempos(el);
			const oculto = Boolean(pistaOculta || ("hidden" in el && el.hidden));
			const texto = el.type === "text" ? String(el.params.content ?? "") : undefined;
			const k = clave(el.name);
			if (k) {
				elementos.push({ k, inicio, fin, texto, oculto });
				continue;
			}
			if (el.type === "image" && !oculto) {
				const a = assets.get(el.mediaId);
				if (!a?.file) continue;
				nuevas.push({ inicio, fin, nombre: a.file.name || a.name || "imagen.jpg", datos: await aBase64(a.file), oculto });
			} else if (el.type === "text" && !oculto && texto) {
				tramosNuevos.push({ inicio, fin, texto });
			}
		}
	}
	return { elementos, nuevas, tramos_nuevos: tramosNuevos };
}

export async function enviarCambios({
	editor,
}: {
	editor: EditorCore;
}): Promise<string> {
	const projectId = editor.project.getActive().metadata.id;
	const v = vinculoDe(projectId);
	if (!v) throw new Error("Este proyecto no viene del editor vertical");
	const cuerpo = JSON.stringify({ t: v.t, firma: v.firma, ...(await bloquesDelProyecto(editor)) });
	// text/plain: así el navegador no pide permiso aparte al otro servidor
	const r = await fetch(`${v.puente}/oc/enviar`, {
		method: "POST",
		headers: { "Content-Type": "text/plain;charset=utf-8" },
		body: cuerpo,
	});
	const d = (await r.json()) as { ok: boolean; mensaje?: string };
	if (!d.ok) throw new Error(d.mensaje || "El editor vertical no aceptó los cambios");
	// Después de guardar, el editor vertical renumera momentos y tramos (y las imágenes nuevas ya son momentos).
	// Cada bloque se empareja por tipo y tiempos con su clave nueva, para seguir corrigiendo y enviando desde
	// este mismo proyecto sin duplicar nada. Si alguno no se puede emparejar, el siguiente envío pedirá reabrirlo.
	try {
		const p = await pedirPropuesta(v.puente, v.t);
		if (p.firma && reetiquetar({ editor, propuesta: p })) {
			guardarVinculo(projectId, { ...v, firma: p.firma });
		}
	} catch {
		/* si falla, el siguiente envío pedirá volver a abrirlo */
	}
	return d.mensaje || "Cambios enviados";
}

/** Pone a cada bloque (con o sin clave) la clave del tramo nuevo con su mismo tipo y tiempos. */
function reetiquetar({
	editor,
	propuesta,
}: {
	editor: EditorCore;
	propuesta: Propuesta;
}): boolean {
	const nuevos = [
		...propuesta.imagenes.map((x) => ({ k: x.k, tipo: "m", inicio: x.inicio, fin: x.fin })),
		...propuesta.pantalla.map((x) => ({ k: x.k, tipo: "pantalla", inicio: x.inicio, fin: x.fin })),
		...(propuesta.titulo ? [{ k: "ti", tipo: "ti", inicio: 0, fin: propuesta.titulo.fin }] : []),
	];
	const usados = new Set<string>();
	const tol = 0.06;
	const { tracks } = editor.scenes.getActiveScene();
	const updates: Array<{ trackId: string; elementId: string; patch: Partial<TimelineElement> }> = [];
	let todosOk = true;
	for (const pista of [tracks.main, ...tracks.overlay, ...tracks.audio] as TimelineTrack[]) {
		for (const el of pista.elements as TimelineElement[]) {
			const k = clave(el.name);
			let tipo: string;
			if (k) tipo = k === "ti" ? "ti" : k[0] === "m" ? "m" : "pantalla";
			else if (el.type === "image") tipo = "m";
			else if (el.type === "text") tipo = "pantalla";
			else continue;   // el video base y lo demás no se emparejan
			const { inicio, fin } = tiempos(el);
			const par = nuevos.find(
				(n) =>
					!usados.has(n.k) &&
					n.tipo === tipo &&
					Math.abs(n.inicio - inicio) < tol &&
					Math.abs(n.fin - fin) < tol,
			);
			if (!par) {
				const oculto = "hidden" in el && el.hidden;
				// un texto o imagen sin clave que no se usó (p. ej. texto libre, imagen oculta) no estorba
				if (k || (el.type === "image" && !oculto)) todosOk = false;
				continue;
			}
			usados.add(par.k);
			if (par.k !== k) {
				const nombre = k ? el.name.replace(/^\[[^\]]*\]/, `[${par.k}]`) : `[${par.k}] ${el.name}`;
				updates.push({ trackId: pista.id, elementId: el.id, patch: { name: nombre } });
			}
		}
	}
	if (updates.length) {
		editor.command.execute({ command: new UpdateElementsCommand({ updates }) });
	}
	return todosOk;
}
